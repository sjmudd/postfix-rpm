#! /bin/sh

# This trivial shell script will modify some Postfix files
# to include support for CDB map/dictionary type.
# This is not done via patch since it is difficult to do
# for numerous Postfix versions at once.  The method used
# here is more safe and simple than of using `patch' utility.
# It is ok to run this script multiple times -- it will only
# touch files that wasn't processed before.
#
# The script accepts one optional argument -- a directory where
# Postfix sources are located, default is the current directory.

dir="${1:-.}"

if [ -f "$dir/src/util/dict_open.c" ] ; then :
else
  echo No Postfix sources found in "$dir" >&2
  echo Please rerun this script at a top-level >&2
  echo Postfix source directory or specify this >&2
  echo directory in a command line as a single argument. >&2
  exit 1
fi

umask 022
echo
echo "Adding CDB dictionary/map support to Postfix sources in $dir"
echo

bckp=.cdbmap
list=

subst() {
  file="$1" search="$2"; shift 2
  if grep "$search" -- "$dir/$file" >/dev/null ; then
    echo "Nothing to be done for $file"
  else
    echo "Adding cdb support to $file..." | tr -d '\n'
    sed "$@" -- "$dir/$file" > "$dir/$file.tmp" || exit
    mv -f -- "$dir/$file" "$dir/$file$bckp" || exit
    mv -f -- "$dir/$file.tmp" "$dir/$file" || exit
    echo " done."
    list="$list
 $file"
  fi
}

subst src/util/Makefile.in dict_cdb.c 's|dict_dbm\.\([coh]\)|dict_cdb.\1 &|'
subst src/util/dict_open.c dict_cdb_open \
   -e '/^static DICT_OPEN_INFO dict_open_info.*/a \
#ifdef HAS_CDB\
    DICT_TYPE_CDB, dict_cdb_open,\
#endif' \
   -e '/^#include <dict\.h>/a \
#include <dict_cdb.h>'

subst src/global/Makefile.in mkmap_cdb 's|mkmap_dbm\.\([co]\)|mkmap_cdb.\1 &|'
subst src/global/mkmap.h mkmap_cdb_open \
 -e '/^#include <dict\.h>/ a\
#include <dict_cdb.h>' \
 -e '/^extern MKMAP \*mkmap_dbm_open/ a \
extern MKMAP *mkmap_cdb_open(const char *);'
subst src/global/mkmap_open.c mkmap_cdb_open \
 -e '/^MKMAP_OPEN_INFO mkmap_types/ a \
#ifdef HAS_CDB\
    DICT_TYPE_CDB, mkmap_cdb_open,\
#endif'

echo
if [ -n "$list" ] ; then
  echo All done.
  echo "Files modified:$list"
  echo "Original files was saved with $bckp extention."
else
  echo "All done.  No files were modified."
fi
echo
