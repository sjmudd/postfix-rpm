/*++
/* NAME
/*	dict_cdb 3
/* SUMMARY
/*	dictionary manager interface to DB files
/* SYNOPSIS
/*	#include <dict_cdb.h>
/*
/*	DICT	*dict_cdb_open(path, open_flags, dict_flags)
/*	const char *path;
/*	int	open_flags;
/*	int	dict_flags;
/*
/* DESCRIPTION
/*	dict_XXX_open() opens the specified DB database.  The result is
/*	a pointer to a structure that can be used to access the dictionary
/*	using the generic methods documented in dict_open(3).
/*
/*	Arguments:
/* .IP path
/*	The database pathname, not including the ".cdb" suffix.
/* .IP open_flags
/*	Flags passed to open().
/* .IP dict_flags
/*	Flags used by the dictionary interface.
/* SEE ALSO
/*	dict(3) generic dictionary manager
/* DIAGNOSTICS
/*	Fatal errors: cannot open file, write error, out of memory.
/* LICENSE
/* .ad
/* .fi
/*	The Secure Mailer license must be distributed with this software.
/* AUTHOR(S)
/*	Michael Tokarev <mjt@tls.msk.ru> based on dict_db.c by
/*	Wietse Venema
/*	IBM T.J. Watson Research
/*	P.O. Box 704
/*	Yorktown Heights, NY 10598, USA
/*--*/

#include "sys_defs.h"

#ifdef HAS_CDB

/* System library. */

#include <sys/stat.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>

/* Utility library. */

#include "msg.h"
#include "mymalloc.h"
#include "vstring.h"
#include "stringops.h"
#include "iostuff.h"
#include "dict.h"
#include "dict_cdb.h"

#include <cdb.h>

/* Application-specific. */

typedef struct {
    DICT    dict;		/* generic members */
    struct cdb cdb;		/* cdb structure */
} DICT_CDB;

/* dict_cdb_lookup - find database entry */

static const char *dict_cdb_lookup(DICT *dict, const char *name)
{
    DICT_CDB *dict_cdb = (DICT_CDB *) dict;
    unsigned vlen;
    int     status = 0;
    static char *buf;
    static unsigned len;
    const char *result = 0;

    dict_errno = 0;

    /* CDB is constant, so do not try to acquire a lock. */

    /*
     * See if this DB file was written with one null byte appended to key and
     * value.
     */
    if (dict->flags & DICT_FLAG_TRY1NULL) {
	status = cdb_find(&dict_cdb->cdb, name, strlen(name) + 1);
	if (status > 0)
	    dict->flags &= ~DICT_FLAG_TRY0NULL;
    }

    /*
     * See if this DB file was written with no null byte appended to key and
     * value.
     */
    if (status == 0 && (dict->flags & DICT_FLAG_TRY0NULL)) {
	status = cdb_find(&dict_cdb->cdb, name, strlen(name));
	if (status > 0)
	    dict->flags &= ~DICT_FLAG_TRY1NULL;
    }
    if (status < 0)
	msg_fatal("error reading %s: %m", dict->name);

    if (status) {
	vlen = cdb_datalen(&dict_cdb->cdb);
	if (len < vlen) {
	    if (buf == 0)
		buf = mymalloc(vlen + 1);
	    else
		buf = myrealloc(buf, vlen + 1);
	    len = vlen;
	}
      if (cdb_read(&dict_cdb->cdb, buf, vlen, cdb_datapos(&dict_cdb->cdb)) < 0)
	  msg_fatal("error reading %s: %m", dict->name);
      buf[vlen] = '\0';
      result = buf;
    }

    /* No locking so not release the lock.  */

    return (result);
}

/* dict_cdb_close - close data base */

static void dict_cdb_close(DICT *dict)
{
    DICT_CDB *dict_cdb = (DICT_CDB *) dict;
    cdb_free(&dict_cdb->cdb);
    close(dict->stat_fd);
    dict_free(dict);
}

/* dict_cdb_open - open data base and create association with data base */

DICT   *dict_cdb_open(const char *path, int open_flags, int dict_flags)
{
    DICT_CDB *dict_cdb;
    struct stat st;
    char   *cdb_path;
    int     fd;

    cdb_path = concatenate(path, ".cdb", (char *) 0);

    if ((fd = open(cdb_path, open_flags, 0644)) < 0)
	msg_fatal("open database %s: %m", cdb_path);

    dict_cdb = (DICT_CDB *) dict_alloc(DICT_TYPE_CDB,
                                       cdb_path, sizeof(*dict_cdb));
#if defined(TINYCDB_VERSION)
    if (cdb_init(&(dict_cdb->cdb), fd) != 0)
	msg_fatal("dict_cdb_open: unable to init %s: %m", cdb_path);
#else
    cdb_init(&(dict_cdb->cdb), fd);
#endif
    dict_cdb->dict.lookup = dict_cdb_lookup;
    dict_cdb->dict.close = dict_cdb_close;
    dict_cdb->dict.stat_fd = fd;
    if (fstat(fd, &st) < 0)
	msg_fatal("dict_db_open: fstat: %m");
    dict_cdb->dict.mtime = st.st_mtime;
    close_on_exec(fd, CLOSE_ON_EXEC);
    dict_cdb->dict.flags = dict_flags | DICT_FLAG_FIXED;
    if ((dict_flags & (DICT_FLAG_TRY1NULL | DICT_FLAG_TRY0NULL)) == 0)
	dict_cdb->dict.flags |= (DICT_FLAG_TRY1NULL | DICT_FLAG_TRY0NULL);
    myfree(cdb_path);
    return (&dict_cdb->dict);
}

#endif /* HAS_CDB */
