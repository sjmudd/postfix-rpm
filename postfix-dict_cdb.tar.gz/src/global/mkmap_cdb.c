/*++
/* NAME
/*	mkmap_cdb 3
/* SUMMARY
/*	create or open database, CDB style
/* SYNOPSIS
/*	#include <mkmap.h>
/*
/*	MKMAP	*mkmap_cdb_open(path)
/*	const char *path;
/*
/* DESCRIPTION
/*	This module implements support for creating DJB's CDB "constant
/*	databases".
/*
/*	mkmap_cdb_open() take a file name, append the ".cdb.tmp" suffix,
/*	create the named DB database.  On close, this file renamed to
/*	file name with ".cdb" suffix appended (without ".tmp" part).
/*	This routine is a CDB-specific helper for the more
/*	general mkmap_open() interface.
/*
/*	All errors are fatal.
/* SEE ALSO
/*	dict_cdb(3), CDB dictionary interface.
/* LICENSE
/* .ad
/* .fi
/*	The Secure Mailer license must be distributed with this software.
/* AUTHOR(S)
/*	Written by Michael Tokarev <mjt@tls.msk.ru> based on mkmap_db by
/*	Wietse Venema
/*	IBM T.J. Watson Research
/*	P.O. Box 704
/*	Yorktown Heights, NY 10598, USA
/*--*/

/* System library. */

#include <sys_defs.h>

#ifdef HAS_CDB

#include <sys/stat.h>

/* Utility library. */

#include <msg.h>
#include <mymalloc.h>
#include <stringops.h>
#include <dict.h>
#include <string.h>
#include <unistd.h>
#include <iostuff.h>
#include <myflock.h>
#include <errno.h>
#include <stdio.h>
#include <myflock.h>

/* Application-specific. */

#include "mkmap.h"
#include <dict_cdb.h>

#ifndef CDB_TEMP_SUFFIX
#define CDB_TEMP_SUFFIX ".tmp"
#endif

#include <cdb.h>
#ifndef TINYCDB_VERSION
# include <cdb_make.h>
#endif
#ifndef cdb_fileno
# define cdb_fileno(c) ((c)->fd)
#endif

typedef struct {
    DICT    dict;		/* generic members */
    struct cdb_make cdbm;	/* cdb_make structure */
    char   *temp_path;		/* temporary pathname */
    char   *path;		/* real pathname, the same as in MKMAP */
} DICT_CDBM;

/* dict_cdbm_update - add database entry.
   Updating is not implemented for cdb */

static void dict_cdbm_update(DICT *dict, const char *name, const char *value)
{
    DICT_CDBM *dict_cdbm = (DICT_CDBM *)dict;
    unsigned ksize, vsize;
    int r;

    ksize = strlen(name);
    vsize = strlen(value);

    /*
     * If undecided about appending a null byte to key and value,
     * then do not append a null byte.
     */
    if ((dict->flags & DICT_FLAG_TRY1NULL)
        && (dict->flags & DICT_FLAG_TRY0NULL)) {
	dict->flags &= ~DICT_FLAG_TRY1NULL;
	dict->flags |= DICT_FLAG_TRY0NULL;
    }

    /*
     * Optionally append a null byte to key and value.
     */
    if (dict->flags & DICT_FLAG_TRY1NULL) {
	ksize++;
	vsize++;
    }

    /*
     * Do the add operation.  No locking is done.
     */
#ifdef TINYCDB_VERSION
#ifndef CDB_PUT_ADD
#error please upgrate tinycdb to at least 0.5 version
#endif
    if (dict->flags & DICT_FLAG_DUP_IGNORE)
	r = CDB_PUT_ADD;
    else if (dict->flags & DICT_FLAG_DUP_REPLACE)
	r = CDB_PUT_REPLACE;
    else
	r = CDB_PUT_INSERT;
    r = cdb_make_put(&dict_cdbm->cdbm, name, ksize, value, vsize, r);
    if (r < 0)
	msg_fatal("error writing %s: %m", dict_cdbm->path);
    else if (r > 0) {
	if (dict->flags & (DICT_FLAG_DUP_IGNORE|DICT_FLAG_DUP_REPLACE))
	    ;
	else if (dict->flags & DICT_FLAG_DUP_WARN)
	    msg_warn("%s: duplicate entry: \"%s\"",
	             dict_cdbm->dict.name, name);
	else
	    msg_fatal("%s: duplicate entry: \"%s\"",
	              dict_cdbm->dict.name, name);
    }
#else
    if (cdb_make_add(&dict_cdbm->cdbm, name, ksize, value, vsize) < 0)
	msg_fatal("error writing %s: %m", dict_cdbm->path);
#endif
}

/* dict_cdbm_close - close data base and rename new temp file to real one */

static void dict_cdbm_close(DICT *dict)
{
    DICT_CDBM *dict_cdbm = (DICT_CDBM *) dict;

    if (cdb_make_finish(&dict_cdbm->cdbm) < 0)
	msg_fatal("finish database %s: %m", dict_cdbm->temp_path);
    if (rename(dict_cdbm->temp_path, dict->name) < 0)
	msg_fatal("rename database from %s to %s: %m",
		  dict_cdbm->temp_path, dict->name);
    if (close(cdb_fileno(&dict_cdbm->cdbm)) < 0)
	msg_fatal("close database %s: %m", dict->name);
    myfree(dict_cdbm->temp_path);
    dict_free(dict);
}


/* mkmap_cdbm_open and dict_cdbm_open (private) - create database.
   DB will always be created in temp location,
   replacing current one on close */

static DICT *dict_cdbm_open(const char *path, int open_flags, int dict_flags)
{
    DICT_CDBM *dict_cdbm;
    char   *temp_cdb_path;
    char   *cdb_path;
    int     fd;

    if (!(open_flags & O_TRUNC))
	msg_fatal("cdb map can not be opened in update mode");

    cdb_path = concatenate(path, ".cdb", (char *) 0);
    temp_cdb_path = concatenate(cdb_path, CDB_TEMP_SUFFIX, (char *) 0);

    if ((fd = open(temp_cdb_path, O_RDWR|O_CREAT|O_TRUNC, 0644)) < 0)
	msg_fatal("open database %s: %m", temp_cdb_path);

    dict_cdbm = (DICT_CDBM *) dict_alloc(DICT_TYPE_CDB, cdb_path,
                                         sizeof(*dict_cdbm));
    if (cdb_make_start(&dict_cdbm->cdbm, fd) < 0)
      msg_fatal("initialize database %s: %m", temp_cdb_path);
    dict_cdbm->dict.close = dict_cdbm_close;
    dict_cdbm->dict.update = dict_cdbm_update;
    dict_cdbm->temp_path = temp_cdb_path;
    close_on_exec(fd, CLOSE_ON_EXEC);
    dict_cdbm->dict.flags = dict_flags | DICT_FLAG_FIXED;
    if ((dict_flags & (DICT_FLAG_TRY1NULL | DICT_FLAG_TRY0NULL)) == 0)
	dict_cdbm->dict.flags |= (DICT_FLAG_TRY1NULL | DICT_FLAG_TRY0NULL);
    myfree(cdb_path);
    return (&dict_cdbm->dict);
}

/*
 * locking algorithm.
 *  open(.cdb file)
 *  lock it
 *  open(.cdb file) -- again
 *  compare fstats on both -- should be the same
 *   if not, repeat from scratch
 */

MKMAP *mkmap_cdb_open(const char *path)
{
    int fd;
    struct stat st0, st1;
    MKMAP  *mkmap = (MKMAP *) mymalloc(sizeof(*mkmap));
    char *cdb_path = concatenate(path, ".cdb", (char *) 0);

    /* repeat until we have opened *and* locked *existed* file */
    for(;;) {

	if ((fd = open(cdb_path, O_CREAT | O_RDWR, 0644)) < 0
	    || fstat(fd, &st0) < 0)
	    msg_fatal("open %s: %m", cdb_path);
	/*
	 * Get an exclusive lock - we're going to change the database
	 * so we can't have any spectators.
	 * XXXX  Unfortunately, the same thing made also in mkmap_open.c --
	 * we rely ability to do the same lock twice by OS, it should be
	 * a noop.
	 * If this is not a case, then the following logic should be moved
	 * somewhere else...  -- mjt.
	 */
	if (myflock(fd, INTERNAL_LOCK, MYFLOCK_OP_EXCLUSIVE) < 0)
	    msg_fatal("lock %s: %m", cdb_path);

	if (stat(cdb_path, &st1) < 0)
	    msg_fatal("stat(%s): %m", cdb_path);

	/*
	 * compare file's state before and after lock: should be
	 * the same, and nlinks should be >0, or else we opened
	 * non-existed file...
	 */
	if (st0.st_ino == st1.st_ino && st0.st_dev == st1.st_dev
	    && st0.st_rdev == st1.st_rdev && st0.st_nlink == st1.st_nlink
	    && st0.st_nlink > 0)
	     break;  /* successefully opened */

	close(fd);

    }

    /*
     * Fill in the generic members.
     */
    mkmap->lock_file = cdb_path;
    mkmap->lock_fd = fd;
    mkmap->open = dict_cdbm_open;

    return (mkmap);
}

#endif /* HAS_CDB */
